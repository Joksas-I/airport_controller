<?php
defined('ENTER') || die;
require __DIR__ .'/vendor/autoload.php';
session_start();
define('DIR', __DIR__.'/');
define('URL', 'http://localhost/airport_controller/public/');
define('INSTALL_DIR', '/airport_controller/public');