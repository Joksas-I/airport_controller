<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand mainLogo" href="<?= URL ?>">
    Airport Control
  </a>
  <div>    
      <a class="navbar-brand" href="<?= URL ?>airports"><i class="fa fa-road" aria-hidden="true"></i> Airports</a>
      <a class="navbar-brand" href="<?= URL ?>airlines"><i class="fa fa-plane" aria-hidden="true"></i> Airlines</a>
      <a class="navbar-brand" href="<?= URL ?>countries"><i class="fa fa-globe" aria-hidden="true"></i> Countries</a>
      <a class="navbar-brand" href="<?= URL ?>summaries"><i class="fa fa-list-alt" aria-hidden="true"></i> Summaries</a>
  </div>
</nav>