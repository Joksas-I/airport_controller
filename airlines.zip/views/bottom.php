<script>
    $('.countrypicker').countrypicker();
  </script> 
</body>
</html>